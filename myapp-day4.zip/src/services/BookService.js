import axios from "axios";

const BASE_URL = "https://jsonplaceholder.typicode.com";

//Retrieve all books records by invoking a rest service.
class BookService {

    fetchAllComments = ()=>{
        return axios.get(BASE_URL + "/comments");
    }

    fetchCommentByPostId =(postId)=>{
       // return axios.get(BASE_URL + "/comments" + "?postId=" + postId);
        return axios.get(BASE_URL + "/comments",
                         {params : {"postId" : postId}}
                        );
    }

    fetchCommentById = (commentId) =>{
        return axios.get(BASE_URL + "/comments/" + commentId);
    }

    
}

export default new BookService();



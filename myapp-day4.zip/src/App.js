import './App.css';
import CommentsForPost from './components/CommentsForPost';
import ListComment from './components/ListComment';
import CommentByID from './components/CommentByID';

function App() {
  
  return (
      <div className='container'>
          <CommentByID/>
          <CommentsForPost/>
          <ListComment/>       
      </div>
  );
}

export default App;

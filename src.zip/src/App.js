import './App.css';
import Person from './components/Person.js';
import Student from './components/Student.js';

function App() {
  
  return (
      <div className='app-backcolor'>
          <h2>Welcome to React Application Development</h2>
          <p>Anish, IBS Softwares.Cochin</p>
          <Person/>
          <Student/>
     
          <h2>App Component continues..</h2>
          <p>App Component End Here.</p>
      </div>
  );
}

export default App;

import './App.css';
import Items from './components/Items.js';

function App() {
  
  return (
      <div className='container'>
          <Items/>       
      </div>
  );
}

export default App;

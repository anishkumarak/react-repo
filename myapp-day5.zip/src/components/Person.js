import './Person.css';

export default function Person() {
    
    return (
        <div className='person-backcolor'>
            <h2>Person Component </h2>
            <table>
                <tr><td>Person Name</td><td>Ramesh Kumar</td></tr>
                <tr><td>Person Age</td><td>45</td></tr>
                <tr><td>Address</td><td>Cochin. Kerala</td></tr>
            </table>
        </div>
    );
}

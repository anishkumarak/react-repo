import React, { Component } from 'react';
import './Employee.css';

export default class Employee extends Component {
    state = {
        employees : [
            {"empno" : 101, "empname" : "Suresh", "salary": 50000.0, "deptno" : 10, "designation" : "Developer"},
            {"empno" : 102, "empname" : "Ajay", "salary": 50000.0, "deptno" : 10, "designation" : "Manager"},
            {"empno" : 103, "empname" : "Anand", "salary": 50000.0, "deptno" : 10, "designation" : "Tester"},
            {"empno" : 104, "empname" : "Kishore", "salary": 50000.0, "deptno" : 10, "designation" : "Executive"}
        ]
      } 

    render() { 
        return (
            <div>
                <h2>Employee List</h2>
                <table class="table table-bordered"> 
                <thead>
                    <tr><td>Empno</td><td>Empname</td><td>Salary</td><td>Deptno</td><td>Designation</td></tr>
                </thead>
                <tbody>
                    {this.state.employees.map((emp=>{
                        let styleclass = (emp.designation === 'Developer') ? 'hilight' : 'app-backcolor';
                        return <tr key={emp.empno} className={styleclass}><td>{emp.empno}</td><td>{emp.empname}</td><td>{emp.salary}</td><td>{emp.deptno}</td><td>{emp.designation}</td></tr>
                    }))}
                </tbody>
                </table>
            </div>
        );
    }
}
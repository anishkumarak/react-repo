import React, { Component } from 'react';
import BookService from '../services/BookService.js';

export default class ListComment extends Component {
    state = {  
        statusMessage : "",
        comments : []
    } 
  
    constructor(){
        super();
        console.log("Constructor executed");
    }

    //life cycle method.
    componentDidMount() {
        console.log("Component mounted on UI");
        BookService.fetchAllComments()
                    .then((response)=>{
                        this.setState({"comments" : response.data});
                    })
                    .catch((error)=>{
                        this.setState({"statusMessage" : "Error while Loading Comments"});
                    });
    }

    render() { 
    
        return (
            <div>
                <h2>List of Comments</h2>
                <table className='table table-bordered table-striped'>
                    <thead>
                        <tr><td>Post ID</td><td>Id</td><td>Name</td><td>Email</td></tr>
                    </thead>
                    <tbody>
                        {this.state.comments.map((comment)=>{
                            return <tr key={comment.id}><td>{comment.postId}</td><td>{comment.id}</td><td>{comment.name}</td><td>{comment.email}</td></tr>
                        })}
                    </tbody>
                </table>
            </div>
        );
    }
}
 
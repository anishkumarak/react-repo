import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'

import CommentsForPost from './components/CommentsForPost';
import ListComment from './components/ListComment';
import CommentByID from './components/CommentByID';
import Header from './components/Header';
import Person from './components/Person';
import ProductCatalogue from './components/ProductCatalogue';
import Employee from './components/Employee';

import './App.css';

function App() {

  return (
    <div className='container'>
      <Router>
        <Header />
        <Routes>
          <Route path="/" exact element={<Person/>}></Route>
          <Route path="/listComments"  element={<ListComment/>}></Route>
          <Route path="/commentByPost" element={<CommentsForPost/>} ></Route>
          <Route path="/commentById" element={<CommentByID/>} ></Route>
          <Route path="/listProduct" element={<ProductCatalogue/>}></Route>
          <Route path="/listEmps" element={<Employee/>}></Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;

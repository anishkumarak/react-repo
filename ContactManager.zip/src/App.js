import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'

import Header from './components/Header';
import NewContact from './components/NewContact';
import Home from './components/Home';
import Aboutus from './components/Aboutus';
import ListContacts from './components/ListContacts';
import ContactInfo from './components/ContactInfo';
import './App.css';
import ErrorPage from './components/ErrorPage';

function App() {

  return (
    <div className='container'>
      <Router>
        <Header />
        <Routes>
          <Route path="/"  exact element={<Home/>}></Route>
          <Route path="/newContact"  element={<NewContact/>}></Route>
          <Route path="/listContacts" element={<ListContacts/>}></Route>
          <Route path="/contactInfo/:contactId" element={<ContactInfo/>}></Route>
          <Route path="/aboutus" element={<Aboutus/>}></Route>
          <Route path="/*" element={<ErrorPage/>}></Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;

import React, { Component } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ContactService from '../services/ContactService';
import './NewContact.css';

export default class NewContact extends Component {
  state = {
    statusMessage : ""
  }
  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  validationSchema() {
    return Yup.object().shape({
      firstName: Yup.string().required('Firstname is required'),
      lastName: Yup.string()
        .required('Lastname is required'),
      emailAddress: Yup.string()
        .required('Email is required')
        .email('Email is invalid'),
      contactNo: Yup.string()
        .required('Contact Number is required')
        .trim(),
      address: Yup.string()
        .required('Address is required')
        .min(10, 'Address must be at least 10 characters')
        .max(50, 'Address must not exceed 50 characters'),
      organization: Yup.string()
        .required('Organization is required')
    });
  }


  handleSubmit(data) {
    console.log(JSON.stringify(data, null, 2));
    ContactService.addNewContact(data)
      .then((resp) => {
         this.setState({'statusMessage' : 'Contact details added successfully'});
      })
      .catch((error) => {
        this.setState({'statusMessage' : 'Error while adding new contact'});
      });
  }

  render() {
    let initialValues = {
      firstName: '',
      lastName: '',
      emailAddress: '',
      contactNo: '',
      address: '',
      organization: ''
    };

    return (
          <Formik
            initialValues={initialValues}
            validationSchema={this.validationSchema}
            onSubmit={this.handleSubmit}>

            {({ resetForm }) => (
              <Form>
                <h2>Add New Contact </h2>
                 <table>
                 <tr><td>&nbsp;</td><td style={{color : "green", fontSize: 15}}>{this.state.statusMessage}</td><td>&nbsp;</td></tr>
                  <tr><td><label>First Name</label></td>
                  <td><Field name="firstName" type="text"/></td>
                  <td><ErrorMessage
                    name="firstName"
                    component="div"
                    className="text-danger"/>
                  </td></tr>
                
                <tr>
                  <td><label htmlFor="lastName"> Last Name </label></td>
                  <td><Field name="lastName" type="text" /></td>
                  <td><ErrorMessage
                    name="lastName"
                    component="div"
                    className="text-danger"
                  /></td>
                </tr>
                <tr>
                  <td><label htmlFor="emailAddress"> Email </label></td>
                  <td><Field name="emailAddress" type="email" /></td>
                  <td><ErrorMessage
                    name="emailAddress"
                    component="div"
                    className="text-danger"
                  /></td>
                </tr>
                <tr>
                  <td><label htmlFor="contactNo"> Contact Number </label></td>
                  <td><Field name="contactNo" type="text"  /></td>
                  <td><ErrorMessage
                    name="contactNo"
                    component="div"
                    className="text-danger"
                  /></td>
                </tr>
                <tr>
                  <td><label htmlFor="address"> Address </label></td>
                  <td><Field name="address" type="text" /></td>
                  <td><ErrorMessage
                    name="address"
                    component="div"
                    className="text-danger"
                  /></td>
                </tr>
                <tr>
                  <td><label htmlFor="*organization"> Organization </label></td>
                  <td><Field name="organization" type="text"  /></td>
                  <td><ErrorMessage
                    name="organization"
                    component="div"
                    className="text-danger"
                  /></td>
                </tr>


                <tr><td>
                  <button type="submit" className="btn btn-primary">
                    Add Contact
                  </button> &nbsp;
                  <button
                    type="button"
                    onClick={resetForm}
                    className="btn btn-warning float-right"
                  >
                    Reset Form
                  </button>
                </td></tr>
                </table>
              </Form>
            )}
          </Formik>
    );
  }
}


const ErrorPage = () => {
    return (
        <div>
            <h2>Error Page</h2>
            <p>Page Under development</p>
        </div>
    );
}

export default ErrorPage;
import React, { Component } from 'react';

class Aboutus extends Component {
    state = {  } 
    render() { 
        return (
            <div>
                Aboutus
            </div>
        );
    }
}
 
export default Aboutus;
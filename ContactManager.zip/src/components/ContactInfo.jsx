import React from 'react';
import { useNavigate } from 'react-router-dom';


const ContactInfo = () => {
    const navigate = useNavigate();
    
    return ( 
        <div>
            <h2>Contact Details</h2>
            <button onClick={()=>{navigate('/listContacts')}}>Go Back</button>
        </div>
     );
}
 
export default ContactInfo;
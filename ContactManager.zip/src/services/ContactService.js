import axios from "axios";

const BASE_URL = "http://localhost:8082/api";

class ContactService {

    addNewContact = (contact) => {
        return axios.post(BASE_URL + "/contact", contact);
    }

    listContacts = () => {
        return axios.get(BASE_URL + "/contacts");
    }

    findContactById = (contactId) => {
        return axios.get(BASE_URL + "/contact",
                            {params : {"contactId" : contactId}}
                        );
    }

}

export default new ContactService();
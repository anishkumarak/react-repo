import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'

import CommentsForPost from './components/CommentsForPost';
import ListComment from './components/ListComment';
import CommentByID from './components/CommentByID';
import Header from './components/Header';
import Person from './components/Person';
import ProductCatalogue from './components/ProductCatalogue';
import Employee from './components/Employee';
import Register from './components/Register';

import './App.css';
import { LifecycleTest } from './components/LifecyleTest';

function App() {

  return (
    <div className='container'>
      <Router>
        <Header />
        <LifecycleTest/>
        <Routes>
          <Route path="/" exact element={<Person/>}></Route>
          <Route path="/listComments"  element={<ListComment/>}></Route>
          <Route path="/commentByPost" element={<CommentsForPost/>} ></Route>
          <Route path="/commentById" element={<CommentByID/>} ></Route>
          <Route path="/listProduct" element={<ProductCatalogue/>}></Route>
          <Route path="/listEmps" element={<Employee/>}></Route>
          <Route path="/registerForm" element={<Register/>}></Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;

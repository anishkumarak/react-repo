import React, { Component } from 'react';

export default class Register extends Component {
    state = { 
        yname : "",
        username : "",
        password : "",
        qualification : "",
        gender : "",
        hobbies : [],
        registerFormErrors : {"ynameError" : "", "usernameError" : "", "passwordError" : "", "qualificationError" : "", "genderError" : ""}, 
        formValid : false        
    } 

    constructor() {
        super();
        this.ynameRef = React.createRef();  
    }
    componentDidMount () {
        this.ynameRef.current.focus();
    }

    ynameHandler = (event) => {
        this.setState({"yname" : event.target.value});
    }

    usernameHandler = (event) =>{
        this.setState({"username" : event.target.value});
    }

    passwordHandler= (event) =>{
        this.setState({"password" : event.target.value});
    }

    qualificationHandler= (event) => {
        this.setState({"qualification" : event.target.value});    
    }

    genderHandler= (event) =>{
        this.setState({"gender" : event.target.value});
    }

    hobbyHandler= (event) =>{
        if(event.target.checked)
            this.state.hobbies.push(event.target.value);    
        else {
            const filteredHobby = this.state.hobbies.filter((hobby)=> event.target.value !== hobby)
            this.setState({"hobbies" : filteredHobby});
        }
            
    }

    handleRegisterUserSubmit= (event) => {
        event.preventDefault();  //
        //const {yname, username, password, qualification, gender, hobbies} = this.state;  //object destructuring
        //console.log(`${yname} , ${username}, ${password}, ${qualification}, ${gender}, ${hobbies} `);
        //validate the form data..
        let formValid = this.validateForm(this.state);
        if(formValid)
            event.target.submit();
        

    }

    validateForm = (formState) =>{
        let formValid = true;
        if(!formState.yname) {
            formValid = false;
            formState.registerFormErrors.ynameError = "Your name field is mandatory";
        }
        else{
            formState.registerFormErrors.ynameError = "";
        }
        if(!formState.username) {
            formValid = false;
            formState.registerFormErrors.usernameError = "Username field is mandatory";
        }
        else{
            formState.registerFormErrors.usernameError = "";
        }
        if(!formState.password) {
            formValid = false;
            formState.registerFormErrors.passwordError = "Password field is mandatory";
        }
        else{
            formState.registerFormErrors.passwordError = "";
        }
        if(!formState.qualification) {
            formValid = false;
            formState.registerFormErrors.qualificationError = "Qualification field is mandatory";
        }
        else{
            formState.registerFormErrors.qualificationError = "";
        }
        if(!formState.gender) {
            formValid = false;
            formState.registerFormErrors.genderError = "Gender field is mandatory";
        }
        else{
            formState.registerFormErrors.genderError = "";
        }

        this.setState({"registerFormErrors" : formState.registerFormErrors});
        return formValid;
    }

    render() { 
        return (
            <div>
                <h2>User Registration Form </h2>
                <form onSubmit={this.handleRegisterUserSubmit}>
                    <table className="table table-striped">
                        <tr><td>Your Name</td><td><input type="text" onChange={this.ynameHandler} ref={this.ynameRef}/></td> <td>{this.state.registerFormErrors.ynameError}</td></tr>
                        <tr><td>User Name</td><td><input type="text" onChange={this.usernameHandler}/></td> <td>{this.state.registerFormErrors.usernameError}</td></tr>
                        <tr><td>Password</td>
                                <td><input type="password" onChange={this.passwordHandler}/></td><td>{this.state.registerFormErrors.passwordError}</td> </tr>
                        <tr><td>Qualification</td>
                            <td>
                                <select onChange={this.qualificationHandler}>
                                    <option value="B.E" selected>B.E</option>
                                    <option value="B.Tech">B.Tech</option>
                                    <option value="MBA">MBA</option>
                                </select>
                            </td>
                            <td>{this.state.registerFormErrors.qualificationError}</td>
                        </tr>
                        <tr><td>Gender</td><td>
                            <input type="radio" name="gender" value="M" onClick={this.genderHandler}/>Male 
                            <input type="radio" name="gender" value="F" onClick={this.genderHandler}/>Female</td> 
                            <td>{this.state.registerFormErrors.genderError}</td>
                            </tr>
                        
                        <tr><td>Hobbies</td>
                            <td>
                                    <input type="checkbox" value="Cooking" onClick={this.hobbyHandler}/>Cooking
                                    <input type="checkbox" value="Dancing" onClick={this.hobbyHandler}/>Dancing
                                    <input type="checkbox" value="Swimming" onClick={this.hobbyHandler}/>Swimming
                            </td>
                        </tr> 
                        <tr><td><button type="submit">Register User</button></td></tr>
                    </table>
                </form>
            </div>
        );
    }
}
 

import React, { Component } from 'react';
import BookService from '../services/BookService';

export default class CommentsForPost extends Component {
    state = {
        postId : 2,
        comments : [],
        statusMessage : ""
      } 

     componentDidMount() {
        BookService.fetchCommentByPostId(this.state.postId)
                                .then((response)=>{
                                    this.setState({"comments" : response.data})
                                })
                                .catch((error)=>{
                                    this.setState({"statusMessage" : "Error while reading comments"})
                                });
     } 

    render() { 
        return (            <div>
               <h2>List of Comments for PostID : {this.state.postId} </h2>
                <table className='table table-bordered table-striped'>
                    <thead>
                        <tr><td>Post ID</td><td>Id</td><td>Name</td><td>Email</td><td>Body</td></tr>
                    </thead>
                    <tbody>
                        {this.state.comments.map((comment)=>{
                            return <tr key={comment.id}><td>{comment.postId}</td><td>{comment.id}</td><td>{comment.name}</td><td>{comment.email}</td><td>{comment.body}</td></tr>
                        })}
                    </tbody>
                </table>
 
            </div>
        );
    }
}
 
 
import React, { Component } from 'react';
import Product from './Product.js';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Items.css';

export default class Items extends Component {
    state = {
        selectedItem: {},
        items: [{ "code": "P001", "description": "Pen", "unitPrice": 50.0, "category": "Stationery", "quantityOnHand": 50, "imageUrl" :'logo192.png' },
        { "code": "P002", "description": "Pencil", "unitPrice": 10.0, "category": "Stationery", "quantityOnHand": 50 ,"imageUrl" :'logo192.png'},
        { "code": "P003", "description": "Eraser", "unitPrice": 5.0, "category": "Stationery", "quantityOnHand": 10 ,"imageUrl" :'logo192.png'},
        { "code": "P004", "description": "Pendrive", "unitPrice": 550.0, "category": "Electronics", "quantityOnHand": 10 ,"imageUrl" :'logo192.png'},
        { "code": "P005", "description": "MobileCharger", "unitPrice": 650.0, "category": "Electronics", "quantityOnHand": 2 ,"imageUrl" :'logo192.png'},
        { "code": "P006", "description": "Coke", "unitPrice": 40.0, "category": "Beverages", "quantityOnHand": 10 ,"imageUrl" :'logo192.png'},
        { "code": "P007", "description": "Pepsi", "unitPrice": 40.0, "category": "Beverages", "quantityOnHand": 10 ,"imageUrl" :'logo192.png'},
        { "code": "P008", "description": "Scale", "unitPrice": 10.0, "category": "Stationery", "quantityOnHand": 10 ,"imageUrl" :'logo192.png'}]
    }

    handleItemClick = (item)=>{
        console.log("Item clicked:" + item.code +"," + item.description);
        this.setState({selectedItem : item});
    }

    render() {
        return (
            <div>
                <div className='grid-container'>
                    {this.state.items.map((item)=>{                     
                        return (<div className="grid-item" onClick={()=>this.handleItemClick(item)}>
                            <img className="imgStyle" src={item.imageUrl} alt=""/>
                            <h3>{item.description}</h3>
                            <h3>{item.unitPrice}</h3>
                        </div>)
                    })}
                    <br/>
                </div>
                <Product item={this.state.selectedItem} />
            </div>
        );
    }
}

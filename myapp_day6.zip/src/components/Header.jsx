import {Link } from 'react-router-dom';

import './Header.css';

const Header = () => {
    return (
        <nav className="navbar navbar-default">
            <div className="container-fluid">
                <div className="navbar-header">
                    <span><img src="ibs.PNG" alt='' /></span>
                </div>
                <ul className='nav navbar-nav'>
                    <Link to='/'><li>Home </li></Link>
                    <Link to="listComments"><li> List Comments </li></Link>
                    <Link to="commentByPost"><li> CommentByPost </li></Link>
                    <Link to="commentByID"><li> CommentByID </li></Link>
                    <Link to="listProduct"><li> Product Catalogue </li></Link>
                    <Link to="listEmps"><li> List Emps </li></Link>
                    <Link to="registerForm"><li> Register Form</li></Link>
                </ul>
            </div>
        </nav>
    );
}

export default Header;
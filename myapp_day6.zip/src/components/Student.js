import React, { Component } from 'react';
import './Student.css';
class Student extends Component {
    state = { 
        rollNo : "19494",
        studentName : "Ramesh",
        marks : 500
     } 
    render() { 
        return (
            <div className='student-backcolor'>
                <h2>Student Information</h2>
                <table>
                    
                    <tr><td>Rollno</td><td>{this.state.rollNo}</td></tr>
                    <tr><td>Student Name</td><td>{this.state.studentName}</td></tr>
                    <tr><td>Marks</td><td>{this.state.marks}</td></tr>
                </table>
            </div>
        );
    }
}
 
export default Student;
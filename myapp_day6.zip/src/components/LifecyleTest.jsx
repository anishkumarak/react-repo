import React, { Component } from 'react';

export class LifecycleTest extends Component {
    state = {  } 

    constructor(){
        super();
        console.log("Constructor executed");
        //event binding, initialize....
    }

    componentDidMount(){
            //invoke some http rquest, axios, fetch api
        console.log("Component mounted");
    }

    render() { 
        return (
            <div>
                {console.log("Render executed")}
                <h2>Testing Lifecyle methods</h2>
            </div>
        );
    }
}
 
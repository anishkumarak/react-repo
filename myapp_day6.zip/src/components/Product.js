import React, { Component } from 'react';

export default class Product extends Component {
    state = {  } 
    
    render() { 
        return (
            <div>
                <table className="table table-bordered">
                    <tr><td>Item Code</td><td>{this.props.item.code}</td></tr>
                    <tr><td>Item Description</td><td>{this.props.item.description}</td></tr>
                    <tr><td>Unitprice</td><td>{this.props.item.unitPrice}</td></tr>
                    <tr><td>Quantity On Hand</td><td>{this.props.item.quantityOnHand}</td></tr>
                    <tr><td>Category</td><td>{this.props.item.category}</td></tr>

                </table>
            </div>
            
        );
    }
}
 
import React, { Component } from 'react';
import BookService from '../services/BookService';

export default class CommentByID extends Component {
    state = {
        commentId: 111,
        comment: {},
        statusMessage: "",
        status: false
    }

    componentDidMount() {
        BookService.fetchCommentById(this.state.commentId)
            .then((response) => {
                this.setState({ "status": true });
                this.setState({ "comment": response.data });
            })
            .catch((error) => {
                this.setState({ "status": false });
                this.setState({ "statusMessage": "Comment ID doesn't exist" });
            });
    }

    render() {
        return (
            <div>
                <h2>Comment for the ID {this.state.commentId}</h2>
                <table className='table table-bordered'>
                    <tr><td>Post Id</td><td>{this.state.comment.postId}</td></tr>
                    <tr><td>Comment Id</td><td>{this.state.comment.id}</td></tr>
                    <tr><td>Name</td><td>{this.state.comment.name}</td></tr>
                    <tr><td>Email</td><td>{this.state.comment.email}</td></tr>
                    <tr><td>Body</td><td>{this.state.comment.body}</td></tr>
                </table>
            </div>

        );
    }
}

import React, {useState, useEffect}   from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import ContactService from '../services/ContactService';
import './ContactInfo.css';

const ContactInfo = () => {
    
    const navigate = useNavigate();
    const {contactId} = useParams();
    const [contact, setContact] = useState({});
    
    useEffect(()=>{
        ContactService.findContactById(`${contactId}`)
                                    .then((response)=>{
                                         setContact(response.data) ;  
                                    })
                                    .catch((error)=>{
                                          console.log(error);  
                                    })         
    });


    return ( 
        <div>
            <h2>Contact Details</h2>
            <table >
                <tr><td class="tdstyle">Contact ID</td><td class="tdstyle">{contact.contactId}</td></tr>
                <tr ><td class="tdstyle">Contact Name</td><td class="tdstyle">{contact.firstName}&nbsp;{contact.lastName}</td></tr>
                <tr ><td class="tdstyle">Email</td><td class="tdstyle">{contact.emailAddress}</td></tr>
                <tr ><td class="tdstyle">Contact No</td><td class="tdstyle">{contact.contactNo}</td></tr>
                <tr ><td class="tdstyle">Contact Address</td><td class="tdstyle">{contact.address}</td></tr>
                <tr ><td class="tdstyle">Organization</td><td class="tdstyle">{contact.organization}</td></tr>
                <tr ><td class="tdstyle"><button onClick={()=>{navigate('/listContacts')}}>Go Back</button></td></tr>
            </table>
            
        </div>
     );
}
 
export default ContactInfo;
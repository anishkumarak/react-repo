import {Link } from 'react-router-dom';

import './Header.css';

const Header = () => {
    return (
        <nav className="navbar navbar-custom">
            <div className="container-fluid">
                <div className="navbar-header">
                    <span className='navbar-brand'> Contact Manager </span>
                    <img src="ibs.PNG" alt='' />
                </div>
                
                <ul className='nav navbar-nav'>
                    <li><Link to='/'> Home </Link> </li>
                    <li> <Link to="newContact"> New Contact </Link></li>
                    <li> <Link to="listContacts"> List Contacts </Link></li>
                    <li> <Link to="aboutus"> About US </Link></li>
                </ul>
            </div>
        </nav>
    );
}

export default Header;
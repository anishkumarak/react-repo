import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


export default class ProductCatalogue extends Component {
    state = { 
        selectedCatagory : 'Electronics',
        availableCategory : ['Stationery', 'Electronics', 'Beverages'],
        products : [{"code" : "P001", "description":"Pen","unitPrice" : 50.0, "category":"Stationery","quantityOnHand":50},
                    {"code" : "P002", "description":"Pencil","unitPrice" : 10.0, "category":"Stationery","quantityOnHand":50},
                    {"code" : "P003", "description":"Eraser","unitPrice" : 5.0, "category":"Stationery","quantityOnHand":10},
                    {"code" : "P004", "description":"Pendrive","unitPrice" : 550.0, "category":"Electronics","quantityOnHand":10},
                    {"code" : "P005", "description":"MobileCharger","unitPrice" : 650.0, "category":"Electronics","quantityOnHand":2},
                    {"code" : "P006", "description":"Coke","unitPrice" : 40.0, "category":"Beverages","quantityOnHand":10},
                    {"code" : "P007", "description":"Pepsi","unitPrice" : 40.0, "category":"Beverages","quantityOnHand":10}]
     } 

    render() { 
        return (
            <div>
                <p>
                    Choose Category 
                    <select>
                        {this.state.availableCategory.map((category)=>{
                           return <option value={category}>{category}</option>
                        })}
                    </select>
                </p>
                <h2>Product Catalogue</h2>
                <table className='table table-bordered table-hover'>
                    <thead>
                    <tr><td>Product Code</td><td>Product Description</td><td>Unit Price</td><td>Quantity</td><td>Category</td></tr>
                    </thead>
                    <tbody>
                    {this.state.products.map((product)=>{
                            if(product.category ===this.state.selectedCatagory) {
                                return  <tr key={product.code}><td>{product.code}</td><td>{product.description}</td><td>{product.unitPrice}</td><td>{product.category}</td><td>{product.quantityOnHand}</td></tr>
                            }
                            else{
                                return ""
                            }    
                    })}
                    </tbody>
                    <tfoot>
                    </tfoot>
                </table>
            </div>
        );
    }
}
 
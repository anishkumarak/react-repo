import './App.css';
import Employee from './components/Employee';
import Person from './components/Person.js';
import ProductCatalogue from './components/ProductCatalogue';
import Student from './components/Student.js';

function App() {
  
  return (
      <div className='app-backcolor'>
          <h2>Welcome to React Application Development</h2>
          <p>Anish, IBS Softwares.Cochin</p>
          <Person/>                 
          <Student/>
      
          <ProductCatalogue/>

          <Employee/>
      </div>
  );
}

export default App;
